import { Link } from "react-router-dom";
import "./Home.css"; // Importamos estilos

export default function Home() {
  return (
    <div className="home">
      <h1>Sistema de Información de Proyectos Tecnológicos</h1>
      <h2>Propósito</h2>
      <p>
        El sistema permite informar, organizar y consultar proyectos realizados
        por estudiantes e investigadores de la institución.
      </p>
      <h2>¿Qué son los proyectos tecnológicos?</h2>
      <p>
        Son iniciativas que aplican ciencia y tecnología para resolver problemas,
        innovar y generar impacto en áreas como software, inteligencia artificial,
        IoT, redes y seguridad.
      </p>
      <h2>Tecnologías utilizadas</h2>
      <div className="card-container">
        <div className="card">React</div>
        <div className="card">Firebase Hosting</div>
        <div className="card">Inteligencia Artificial (Copilot)</div>
      </div>
      <Link className="catalogo-link" to="/catalogo">
        Ir al Catálogo de Proyectos
      </Link>
    </div>
  );
}

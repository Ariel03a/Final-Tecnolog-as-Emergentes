import React, { useState } from "react";
import { projects } from "../data/projects.js";
import "./Catalogo.css"; // Importamos estilos

export default function Catalogo() {
  const [filtro, setFiltro] = useState("");
  const [orden, setOrden] = useState("");

  const proyectosFiltrados = projects
    .filter((p) =>
      filtro ? p.area === filtro || p.estado === filtro || p.impacto === filtro : true
    )
    .sort((a, b) => {
      if (!orden) return 0;
      return a[orden].localeCompare(b[orden]);
    });

  return (
    <div className="catalogo">
      <h1>Catálogo de Proyectos Tecnológicos</h1>
      <div className="filtros">
        <label>Filtrar por: </label>
        <select onChange={(e) => setFiltro(e.target.value)}>
          <option value="">Todos</option>
          <option value="IA">IA</option>
          <option value="IoT">IoT</option>
          <option value="Web">Web</option>
          <option value="Redes">Redes</option>
          <option value="Seguridad">Seguridad</option>
          <option value="Software">Software</option>
          <option value="Propuesto">Propuesto</option>
          <option value="En Desarrollo">En Desarrollo</option>
          <option value="Finalizado">Finalizado</option>
          <option value="Alto">Alto</option>
          <option value="Medio">Medio</option>
          <option value="Bajo">Bajo</option>
        </select>

        <label>Ordenar por: </label>
        <select onChange={(e) => setOrden(e.target.value)}>
          <option value="">Ninguno</option>
          <option value="nombre">Nombre</option>
          <option value="area">Área</option>
          <option value="estado">Estado</option>
          <option value="impacto">Impacto</option>
        </select>
      </div>

      <div className="card-container">
        {proyectosFiltrados.map((p, i) => (
          <div className="card" key={i}>
            <h3>{p.nombre}</h3>
            <p><strong>Área:</strong> {p.area}</p>
            <p><strong>Estado:</strong> {p.estado}</p>
            <p><strong>Impacto:</strong> {p.impacto}</p>
            <p>{p.descripcion}</p>
          </div>
        ))}
      </div>
    </div>
  );
}
